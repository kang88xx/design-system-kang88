Google Product Observation source kit

Start with data/curated/tokens.css and recipes.css. Open example.html to preview offline.
Implementation source: viewer/template.html and viewer/*workbench.js/css. The template uses build placeholders; use it as integration source, not standalone HTML. InteractionWorkbench.sample(id), motionLab(data), and bind() implement the executable states.
81 official Material Symbols SVGs retain their Apache-2.0 licenses in assets/upstream/.
Observations: product captures 2026-09-01. Official upstream reviewed 2026-09-07.
Recipes labeled reconstructed are independent implementations, not exact Google product source.
Google product marks, illustrations and screenshots are not included.
Source URLs and SHA-256: data/sources/open-source-manifest.json
