# 실행 가능한 모션·인터랙션 샘플

압축을 풀고 `samples/index.html`을 브라우저에서 여세요. 각 샘플은 CSS와 JS가 내장되어 외부 파일이나 네트워크 없이 실행됩니다.

프로젝트에는 `design-system/tokens.css`와 필요한 `motion-kit.css/.js` 또는 `interaction-kit.css/.js`를 옮기세요. `*-samples.json`의 html을 DOM에 넣고 `ReferenceMotion.mount(container)` 또는 `ReferenceInteractions.mount(container)`를 호출합니다. 반환된 cleanup을 화면 제거 시 호출하세요.

공통 API: mount(root), replay(root), setPaused(boolean), setSpeed(number). pause와 speed는 라이브러리 전체에 적용됩니다. 정확한 원본 타이밍과 미관찰 hover/로딩/오류 상태는 제안값입니다. 폼은 네트워크 전송 없는 데모입니다.

이 ZIP은 재사용 코드와 독립 샘플 묶음입니다. 레퍼런스 원본 영상, Motion Lab 비교 UI, 브라우저 검증 캡처는 작업 폴더에 별도로 보관합니다.
